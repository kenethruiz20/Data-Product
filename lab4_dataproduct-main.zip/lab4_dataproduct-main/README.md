# Lab 4: Movie Dashboard

## Integrantes del Grupo: Sebastian Rivera, Keneth Ruiz y Esteban Samayoa

- Se utilizó un dataset de peliculas la cual contenía:
        - Titulo
        - Rating
        - Año de Release
        - Mes de Release
        - Clasificación
        - Duración
        - Directores
        - Cast
        - Genero
        - Lugar de filmación
        - Presupuesto
        - Ingreso
        - Lugar de origen de la pelicula

  - Se publicó el Shiny App a traves de shinyapps.io
  - Se puede ver en el link: https://estebansamayoa.shinyapps.io/lab4_movies/
  
